package com.example.lecture

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper


class DBHelper (context: Context) : SQLiteOpenHelper(context, "USERDB", null, 1){
    override fun onCreate(db: SQLiteDatabase?) {
        db?.execSQL("CREATE TABLE USERS(USERNAME TEXT PRIMARY KEY, PASS TEXT)")
        db?.execSQL("CREATE TABLE SONGS(ID INTEGER PRIMARY KEY, TITLE TEXT, ARTIST TEXT)")
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {
        //TODO("Not yet implemented")
    }

    fun insertSong(title: String, artist: String){
        val db: SQLiteDatabase = writableDatabase
        val cv: ContentValues = ContentValues()
        cv.put("TITLE", title)
        cv.put("ARTIST", artist)
        db.insert("SONGS", null, cv)
        db.close()
    }

    fun getSongs(): MutableList<Song> {
        val db = writableDatabase
        val query = "SELECT * FROM SONGS ORDER BY RAND() LIMIT 7"
        val cursor = db.rawQuery(query, null)
        val songs = mutableListOf<Song>()

        if(cursor.moveToFirst())
        {
            do {
                var song = Song(cursor.getString(0), cursor.getString(1))
                songs.add(song)
            } while(cursor.moveToNext())
            cursor.close()
        }
        db.close()
        return songs
    }

    fun insertUser(username: String, password: String) {
        val db: SQLiteDatabase = writableDatabase
        val cv: ContentValues = ContentValues()
        cv.put("USERNAME", username)
        cv.put("PASS", password)
        db.insert("USERS", null, cv)
        db.close()
    }

    fun existingUser(username: String) : Boolean{
        val db = writableDatabase
        val query = "SELECT * FROM USERS WHERE USERNAME='$username'"
        val cursor = db.rawQuery(query, null)
        if(cursor.count <= 0){
            cursor.close()
            return false
        }
        cursor.close()
        return true
    }

    fun login(username: String, password: String) : Boolean{
        val db = writableDatabase
        val query = "SELECT * FROM USERS WHERE USERNAME='$username' AND PASS='$password'"
        val cursor = db.rawQuery(query, null)
        if(cursor.count == 1){
            cursor.close()
            return true
        }
        cursor.close()
        return false
    }




}