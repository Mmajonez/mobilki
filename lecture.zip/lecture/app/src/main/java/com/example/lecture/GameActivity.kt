package com.example.lecture

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout


class GameActivity : AppCompatActivity() {
    lateinit var title: TextView
    lateinit var artist: TextView
    lateinit var layout: ConstraintLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        title = findViewById(R.id.title)
        artist = findViewById(R.id.artist)
        layout = findViewById(R.id.gameLayout)

        val logged = intent.getStringExtra("logged").toBoolean()

        val db = DBHelper(applicationContext)
        val songs: List<Song> = db.getSongs()

        var i = 0
        title.text = songs[i].title
        artist.text = songs[i].artist

        layout.setOnClickListener() {
            i += 1
            if (i > 6) {
                val intent = Intent(this, MainActivity::class.java)
                intent.putExtra("logged", logged)
                startActivity(intent)
                finish()
            } else {
                title.text = songs[i].title
                artist.text = songs[i].artist
            }
        }
    }

    override fun onPause() {
        super.onPause()
    }
}