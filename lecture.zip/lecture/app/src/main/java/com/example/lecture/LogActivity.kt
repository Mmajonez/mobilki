package com.example.lecture

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class LogActivity : AppCompatActivity() {

    lateinit var username: EditText
    lateinit var password: EditText
    lateinit var login: Button
    lateinit var signup: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_log)

        username = findViewById(R.id.username)
        password = findViewById(R.id.password)
        login = findViewById(R.id.logButton)
        signup = findViewById(R.id.signButton)

        var helper = DBHelper(applicationContext)

        login.setOnClickListener{
            if(helper.login(username.text.toString(), password.text.toString())){
                val intent = Intent(this, MainActivity::class.java)
                intent.putExtra("logged", true)
                startActivity(intent)
            }
            else{
                val text = "Wrong username or password"
                val duration = Toast.LENGTH_LONG
                val toast = Toast.makeText(applicationContext, text, duration)
                toast.show()
                password.text.clear()
            }
        }

        signup.setOnClickListener{
            startActivity(Intent(this,SignActivity::class.java))
        }

    }

    override fun onPause() {
        super.onPause()
    }
}