package com.example.lecture

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class SignActivity : AppCompatActivity() {
    lateinit var username: EditText
    lateinit var password: EditText
    lateinit var repassword: EditText
    lateinit var signup: Button
    lateinit var signin: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign)

        username = findViewById(R.id.username)
        password = findViewById(R.id.password)
        repassword = findViewById(R.id.repassword)
        signup = findViewById(R.id.signButton)
        signin = findViewById(R.id.logButton)

        var helper = DBHelper(applicationContext)

        signup.setOnClickListener{
            if(username.text.isEmpty() || password.text.isEmpty() || repassword.text.isEmpty()){
                val text = "Fields cannot be empty!!"
                val duration = Toast.LENGTH_LONG
                val toast = Toast.makeText(applicationContext, text, duration)
                toast.show()
            }
            else{
                if(!helper.existingUser(username.text.toString())){
                    if (password.text.toString() == repassword.text.toString()){
                        helper.insertUser(username.text.toString(), password.text.toString())
                        val text = "Signed correctly, now you can log in!"
                        val duration = Toast.LENGTH_LONG
                        val toast = Toast.makeText(applicationContext, text, duration)
                        toast.show()
                        startActivity(Intent(this,LogActivity::class.java))
                        finish()
                    }
                    else{
                        val text = "Passwords must match!"
                        val duration = Toast.LENGTH_LONG
                        val toast = Toast.makeText(applicationContext, text, duration)
                        toast.show()
                        password.text.clear()
                        repassword.text.clear()
                    }
                }
                else{
                    val text = "Username is already taken!"
                    val duration = Toast.LENGTH_LONG
                    val toast = Toast.makeText(applicationContext, text, duration)
                    toast.show()
                    username.text.clear()
                    password.text.clear()
                    repassword.text.clear()
                }
            }

        }

        signin.setOnClickListener {
            startActivity(Intent(this, LogActivity::class.java))
        }
    }

    override fun onDestroy() {
        super.onDestroy()
    }

}