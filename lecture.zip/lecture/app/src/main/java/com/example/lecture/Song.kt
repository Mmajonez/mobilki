package com.example.lecture

class Song {
    var title: String
    var artist: String

    constructor(title: String, artist: String) {
        this.title = title
        this.artist = artist
    }
}