package com.example.lecture

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.core.view.isVisible
import kotlin.math.log

class MainActivity : AppCompatActivity() {
    lateinit var play: Button
    lateinit var logout: Button
    lateinit var add: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        play = findViewById(R.id.play)
        logout = findViewById(R.id.logout)
        add = findViewById(R.id.add)

        val logged = intent.getStringExtra("logged").toBoolean()

        if(logged){
            logout.setOnClickListener(){
                logout.text = "Logout"
                add.isVisible = true
                val intent = Intent(this, MainActivity::class.java)
                intent.putExtra("logged", false)
                startActivity(intent)
            }
        }
        else{
            logout.text = "Log In"
            add.isVisible = false
            logout.setOnClickListener(){
                val intent = Intent(this, LogActivity::class.java)
                startActivity(intent)
            }
        }

        add.setOnClickListener(){
            val intent = Intent(this, AddSongActivity::class.java)
            startActivity(intent)
            finish()
        }

        play.setOnClickListener(){
            val intent = Intent(this, GameActivity::class.java)
            intent.putExtra("logged", logged)
            startActivity(intent)
            finish()
        }

    }

}