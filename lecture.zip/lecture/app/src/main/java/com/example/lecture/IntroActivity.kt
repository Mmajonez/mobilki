package com.example.lecture

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import com.example.lecture.DBHelper
import com.example.lecture.LogActivity
import com.example.lecture.R
import org.json.JSONArray
import java.net.URL

class IntroActivity : AppCompatActivity() {
    lateinit var db : DBHelper

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.hide()


        val thread = Thread() {
            run {

                // DB
                db = DBHelper(this)

                val url="https://api.npoint.io/bf02001900ead198f311"
                val body = URL(url).readText()

                if(body!="")
                {
                    val songs =  JSONArray(body)

                    for(i in 0 until songs.length())
                    {
                        var song = songs.getJSONObject(i)
                        db.insertSong(song.getString("title"), song.getString("artist"))
                    }

                }
                db.close()
            }
            runOnUiThread() {

                val intent = Intent(this, MainActivity::class.java)
                intent.putExtra("logged", false)
                startActivity(intent)
            }
        }
        thread.start()

        val thread2 = Thread(){
            run{
                Thread.sleep(3500)
            }
            runOnUiThread(){
                this.onDestroy()
            }
        }
        thread2.start()

    }

    override fun onDestroy() {
        super.onDestroy()
    }
}