package com.example.lecture

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class AddSongActivity : AppCompatActivity() {
    lateinit var title: EditText
    lateinit var artist: EditText
    lateinit var add: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_song)

        title = findViewById(R.id.add_title)
        artist = findViewById(R.id.add_artist)
        add = findViewById(R.id.addButton)

        var helper = DBHelper(applicationContext)

        add.setOnClickListener{
            helper.insertSong(title.text.toString(), artist.text.toString())
            val intent = Intent(this, MainActivity::class.java)
            intent.putExtra("logged", true)
            startActivity(intent)
            finish()
        }

    }

    override fun onPause() {
        super.onPause()
    }
}